# Criado por Alexsander Rosante (12/03/20)

idioma = 'pt-br'
fps = 60
tela_largura = 1366
tela_altura = 768
bloco_largura = 160  # Estático
bloco_altura = 160  # Estático
