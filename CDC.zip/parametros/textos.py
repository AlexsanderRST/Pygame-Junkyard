# Criado por Alexsander Rosante

infobar = {'pt-br': {'pedra': 'Pedra', 'graveto': 'Graveto'}}
