# Criado por Alexsander Rosante

preto = (0, 0, 0)
branco = (255, 255, 255)
vermelho = (255, 0, 0)
verde = (0, 255, 0)
azul = (0, 0, 255)
amarelo = (0, 255, 255)
rosa = (255, 0, 255)
dimgray = (105, 105, 105)
bluesky = (135, 206, 235)
# Usados na textura de terra marrom:
marrom1 = (179, 134, 92)
marrom2 = (147, 109, 72)
marrom3 = (119, 86, 53)
cinza1 = (105, 107, 104)
