# Criado por Alexsander Rosante

from Sistema.cores import *
from math import *

tela_largura, tela_altura = 1366, 768
tela_centro = (tela_largura//2, tela_altura//2)
aceleracao_gravidade = 10
fundo_largura, fundo_altura = 2400, 1600
cor_do_fundo = bluesky
# Pixeis
tamanho_do_pixel = 5
pixeis_por_bloco = sqrt(256)
limite_de_pixeis = 256
