# Criado por Alexsander Rosante

tela_largura = 1366
tela_altura = 768
