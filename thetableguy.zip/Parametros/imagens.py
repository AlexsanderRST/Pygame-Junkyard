# Criado por Alexsander Rosante

principal = "Imagens/objetos/principal.png"
mesa = "Imagens/objetos/mesa.png"
smartfone = "Imagens/objetos/smartfone.png"
