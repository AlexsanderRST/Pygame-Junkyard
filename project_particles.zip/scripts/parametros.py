# Criado por Alexsander Rosante

# geral
tela_largura, tela_altura = 1366, 768
fps = 60
# cores
branco = [255, 255, 255]
vermelho = [255, 0, 0]
verde = [0, 255, 0]
azul = [0, 0, 255]
preto = [0, 0, 0]
# partículas
particula_raio = 32
particulas_disponiveis = [vermelho, verde, azul, branco]

